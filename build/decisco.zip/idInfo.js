"use strict;";
class IdInfo {
  constructor() {
    this.ids = {eagfmmihpdhohgeopinpmdjahojojfjc: "naehniaidbmipnejimaijjoccihghpkd", jcdhmojfecjfmbdpchihbeilohgnbdci: "cpnjigmgeapagmdimmoenaghmhilodfg", hgooncgafgjlbcjlejmijfjidfohhnag: "jenfeoaahmlnlbppldmjdipmfdliepmo", ohlihmmnkclfodpgfddmafdnkcicgfae: "hojgnaofkekpdknepedpmpffpgikfhjn"};
  }
}
